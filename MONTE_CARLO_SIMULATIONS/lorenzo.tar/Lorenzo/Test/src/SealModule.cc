#include "FWCore/Framework/interface/MakerMacros.h"

#include "Lorenzo/Test/interface/LorenzoGenerator.h"

using edm::LorenzoGenerator;
DEFINE_FWK_MODULE(LorenzoGenerator);
