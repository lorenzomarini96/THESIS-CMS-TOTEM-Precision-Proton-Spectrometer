/****************************************************************************
 *
 * This is a part of CTPPS offline software.
 * Authors:
 *   Jan Kašpar
 *
 ****************************************************************************/

#include "Lorenzo/Test/interface/LorenzoGenerator.h"

#include "FWCore/Framework/interface/Event.h"
#include "FWCore/ParameterSet/interface/ParameterSet.h"
#include "FWCore/MessageLogger/interface/MessageLogger.h"
#include "FWCore/ServiceRegistry/interface/Service.h"
#include "FWCore/Framework/interface/EventSetup.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "FWCore/Utilities/interface/RandomNumberGenerator.h"

#include "HepPDT/ParticleDataTable.hh"
#include "SimGeneral/HepPDTRecord/interface/ParticleDataTable.h"

using namespace edm;
using namespace std;

//----------------------------------------------------------------------------------------------------

LorenzoGenerator::LorenzoGenerator(const edm::ParameterSet& pset) : 
  parameterExample(pset.getParameter<double>("parameterExample"))
{
  printf(">> LorenzoGenerator::LorenzoGenerator > parameterExample = %.0f\n", parameterExample);

  produces<HepMCProduct>("unsmeared");
}

//----------------------------------------------------------------------------------------------------

void LorenzoGenerator::produce(edm::Event &e, const edm::EventSetup& es) 
{
  printf(">> LorenzoGenerator::produce > event %llu\n", e.id().event());

  // get conditions
  edm::Service<edm::RandomNumberGenerator> rng;
  CLHEP::HepRandomEngine* engine = &rng->getEngine(e.streamID());

  ESHandle<HepPDT::ParticleDataTable> pdgTable;
  es.getData(pdgTable);

  // prepare HepMC event
  HepMC::GenEvent *fEvt = new HepMC::GenEvent();
  fEvt->set_event_number(e.id().event());
   
  // generate vertex position
  HepMC::GenVertex *vtx = new HepMC::GenVertex(HepMC::FourVector(0., 0., 0., 0.));
  fEvt->add_vertex(vtx);

  // generate outgoing particles
  unsigned int particleId = 2212; // proton

  const HepPDT::ParticleData *pData = pdgTable->particle(HepPDT::ParticleID(particleId));
  double mass = pData->mass().value();

  unsigned int barcode = 0;

  // the following block can be repeated as many times as needed
  {
    // example of random number generation
    const double xi = CLHEP::RandFlat::shoot(engine, 0.02, 0.10);
    const double theta_x = CLHEP::RandGauss::shoot(engine, 0E-6, 50E-6);
    const double theta_y = CLHEP::RandGauss::shoot(engine, 0E-6, 50E-6);

    // determine particle four-momentum
    const double cos_theta = sqrt(1. - theta_x*theta_x - theta_y*theta_y);

    const double energy = 6500.;
    const double p_nom = sqrt(energy*energy - mass*mass);
    const double p = p_nom * (1. - xi);
    const double e = sqrt(p*p + mass*mass);

    HepMC::FourVector momentum(
      p * theta_x,
      p * theta_y,
      p * cos_theta,
      e
    );

    printf("    generated particle with momentum: %.3E, %.3E, %.3E\n", momentum.x(), momentum.y(), momentum.z());

    HepMC::GenParticle* particle = new HepMC::GenParticle(momentum, particleId, 1);
    particle->suggest_barcode(++barcode);
    vtx->add_particle_out(particle);
  }

  // save output
  std::unique_ptr<HepMCProduct> output(new HepMCProduct()) ;
  output->addHepMCData(fEvt);
  e.put(std::move(output), "unsmeared");
}

//----------------------------------------------------------------------------------------------------

LorenzoGenerator::~LorenzoGenerator()
{
}
